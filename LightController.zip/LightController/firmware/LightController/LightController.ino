/*
 * Light Controller firmware: 4 relays over Wi-Fi.
 * Works on ESP32 and ESP8266 (NodeMCU / Wemos D1 mini). Select your board in Arduino IDE.
 *
 * The board creates its own Wi-Fi hotspot. Connect the phone to it, then press
 * Connect in the app (default address 192.168.4.1).
 *
 * HTTP API (used by the Android app):
 *   GET /status                -> "0101"   one char per light, '1' = ON
 *   GET /switch?id=N&state=on  -> "0101"   N = 1..4, state = on | off; returns new status
 */

#if defined(ESP32)
  #include <WiFi.h>
  #include <WebServer.h>
  WebServer server(80);
  const uint8_t RELAY_PINS[4] = {16, 17, 18, 19};    // change to your wiring
#elif defined(ESP8266)
  #include <ESP8266WiFi.h>
  #include <ESP8266WebServer.h>
  ESP8266WebServer server(80);
  const uint8_t RELAY_PINS[4] = {D1, D2, D5, D6};    // change to your wiring
#else
  #error "Select an ESP32 or ESP8266 board"
#endif

// ---- Settings ----
const char* AP_SSID     = "LightController";
const char* AP_PASSWORD = "12345678";          // at least 8 characters
const bool  RELAY_ACTIVE_LOW = true;           // most cheap relay modules switch ON when the pin is LOW

IPAddress apIP(192, 168, 4, 1);
IPAddress apMask(255, 255, 255, 0);

bool lightOn[4] = {false, false, false, false};

void applyRelay(int i) {
  bool level = lightOn[i] ? !RELAY_ACTIVE_LOW : RELAY_ACTIVE_LOW;
  digitalWrite(RELAY_PINS[i], level ? HIGH : LOW);
}

String statusString() {
  String s;
  for (int i = 0; i < 4; i++) s += lightOn[i] ? '1' : '0';
  return s;
}

void handleStatus() {
  server.send(200, "text/plain", statusString());
}

void handleSwitch() {
  if (!server.hasArg("id") || !server.hasArg("state")) {
    server.send(400, "text/plain", "need id and state");
    return;
  }
  int id = server.arg("id").toInt();
  String state = server.arg("state");
  state.toLowerCase();
  if (id < 1 || id > 4 || (state != "on" && state != "off")) {
    server.send(400, "text/plain", "bad id or state");
    return;
  }
  lightOn[id - 1] = (state == "on");
  applyRelay(id - 1);
  server.send(200, "text/plain", statusString());
}

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < 4; i++) {
    pinMode(RELAY_PINS[i], OUTPUT);
    applyRelay(i);                 // start with all lights OFF
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(apIP, apIP, apMask);
  WiFi.softAP(AP_SSID, AP_PASSWORD);
  Serial.print("Hotspot ready, IP: ");
  Serial.println(WiFi.softAPIP());

  server.on("/status", handleStatus);
  server.on("/switch", handleSwitch);
  server.onNotFound([]() { server.send(404, "text/plain", "not found"); });
  server.begin();
}

void loop() {
  server.handleClient();
}
