package com.prateek.lightcontroller

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

const val SWITCH_COUNT = 4
const val DEFAULT_HOST = "192.168.4.1"

data class UiState(
    val host: String = DEFAULT_HOST,
    val connecting: Boolean = false,
    val connected: Boolean = false,
    val switches: List<Boolean> = List(SWITCH_COUNT) { false },
    val busy: Set<Int> = emptySet(),
    val message: String? = null,
)

class LightViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val client = SwitchClient(app)

    private val _state = MutableStateFlow(UiState(host = prefs.getString("host", DEFAULT_HOST)!!))
    val state: StateFlow<UiState> = _state

    fun onHostChange(value: String) = _state.update { it.copy(host = value, message = null) }

    fun connect() {
        val host = _state.value.host.trim()
        if (host.isEmpty()) {
            _state.update { it.copy(message = "Enter the controller's IP address") }
            return
        }
        prefs.edit().putString("host", host).apply()
        _state.update { it.copy(connecting = true, message = null) }
        viewModelScope.launch {
            try {
                val status = client.status(host, SWITCH_COUNT)
                _state.update {
                    it.copy(
                        connecting = false,
                        connected = true,
                        switches = status ?: it.switches,
                        message = "Connected to $host",
                    )
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        connecting = false,
                        connected = false,
                        message = "Couldn't reach $host. Is the phone on the controller's Wi-Fi?",
                    )
                }
            }
        }
    }

    fun disconnect() = _state.update { it.copy(connected = false, message = null) }

    fun setSwitch(index: Int, on: Boolean) {
        val host = _state.value.host.trim()
        _state.update { it.copy(busy = it.busy + index, message = null) }
        viewModelScope.launch {
            try {
                val status = client.setSwitch(host, index + 1, on, SWITCH_COUNT)
                _state.update { s ->
                    val updated = status ?: s.switches.toMutableList().also { it[index] = on }
                    s.copy(switches = updated, busy = s.busy - index)
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(busy = it.busy - index, message = "Light ${index + 1}: command failed (${e.message})")
                }
            }
        }
    }

    /** Sends the four commands one after another so the replies can't arrive out of order. */
    fun setAll(on: Boolean) {
        val host = _state.value.host.trim()
        val all = (0 until SWITCH_COUNT).toSet()
        _state.update { it.copy(busy = all, message = null) }
        viewModelScope.launch {
            for (i in 0 until SWITCH_COUNT) {
                try {
                    val status = client.setSwitch(host, i + 1, on, SWITCH_COUNT)
                    _state.update { s ->
                        s.copy(switches = status ?: s.switches.toMutableList().also { it[i] = on }, busy = s.busy - i)
                    }
                } catch (e: Exception) {
                    _state.update { it.copy(busy = it.busy - i, message = "Light ${i + 1}: command failed (${e.message})") }
                }
            }
        }
    }
}
