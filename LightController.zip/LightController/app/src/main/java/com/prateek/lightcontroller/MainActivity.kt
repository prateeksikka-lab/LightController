package com.prateek.lightcontroller

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { LightControlScreen() }
            }
        }
    }
}

@Composable
fun LightControlScreen(vm: LightViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Light Controller", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)

        // Connection section
        OutlinedTextField(
            value = state.host,
            onValueChange = vm::onHostChange,
            label = { Text("Controller IP address") },
            placeholder = { Text(DEFAULT_HOST) },
            singleLine = true,
            enabled = !state.connected && !state.connecting,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
            modifier = Modifier.fillMaxWidth(),
        )

        if (state.connected) {
            OutlinedButton(onClick = vm::disconnect, modifier = Modifier.fillMaxWidth()) { Text("Disconnect") }
        } else {
            Button(onClick = vm::connect, enabled = !state.connecting, modifier = Modifier.fillMaxWidth()) {
                if (state.connecting) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Connecting…")
                } else {
                    Text("Connect")
                }
            }
        }

        state.message?.let {
            Text(
                it,
                color = if (state.connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        // Switches
        if (state.connected) {
            HorizontalDivider()
            state.switches.forEachIndexed { index, on ->
                LightCard(
                    name = "Light ${index + 1}",
                    on = on,
                    busy = index in state.busy,
                    onToggle = { vm.setSwitch(index, it) },
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalButton(onClick = { vm.setAll(true) }, modifier = Modifier.weight(1f)) { Text("All ON") }
                FilledTonalButton(onClick = { vm.setAll(false) }, modifier = Modifier.weight(1f)) { Text("All OFF") }
            }
            TextButton(onClick = vm::connect, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Refresh status")
            }
        }
    }
}

@Composable
private fun LightCard(name: String, on: Boolean, busy: Boolean, onToggle: (Boolean) -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (on) Color(0xFFFFC83D) else Color(0xFF9E9E9E).copy(alpha = 0.35f))
            )
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (on) "ON" else "OFF",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (busy) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
            }
            Switch(checked = on, onCheckedChange = onToggle, enabled = !busy)
        }
    }
}
