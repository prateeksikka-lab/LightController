package com.prateek.lightcontroller

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to the light controller over plain HTTP.
 *
 * Protocol (implemented by firmware/LightController.ino):
 *   GET /status                  -> "0101"  (one char per switch, '1' = ON)
 *   GET /switch?id=N&state=on    -> "0101"  (N = 1..4, state = on|off; returns new status)
 */
class SwitchClient(context: Context) {

    private val cm = context.getSystemService(ConnectivityManager::class.java)

    /**
     * A controller hotspot has no internet, so Android may route requests over
     * mobile data instead. Sending through the Wi-Fi network explicitly avoids that.
     */
    @Suppress("DEPRECATION")
    private fun wifiNetwork(): Network? =
        cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }

    private suspend fun get(host: String, path: String): String = withContext(Dispatchers.IO) {
        val url = URL("http://${host.trim()}$path")
        val conn = (wifiNetwork()?.openConnection(url) ?: url.openConnection()) as HttpURLConnection
        conn.connectTimeout = 3000
        conn.readTimeout = 3000
        conn.requestMethod = "GET"
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("Controller replied HTTP $code")
            conn.inputStream.bufferedReader().use { it.readText() }.trim()
        } finally {
            conn.disconnect()
        }
    }

    /** Returns the state of each switch, or null if the reply wasn't a status string. */
    private fun parseStatus(body: String, count: Int): List<Boolean>? {
        val bits = body.filter { it == '0' || it == '1' }
        return if (bits.length >= count) bits.take(count).map { it == '1' } else null
    }

    suspend fun status(host: String, count: Int): List<Boolean>? =
        parseStatus(get(host, "/status"), count)

    suspend fun setSwitch(host: String, id: Int, on: Boolean, count: Int): List<Boolean>? =
        parseStatus(get(host, "/switch?id=$id&state=${if (on) "on" else "off"}"), count)
}
